package WorkingApp;
use Dancer ':syntax';

get '/app' => sub { "app" };

1;

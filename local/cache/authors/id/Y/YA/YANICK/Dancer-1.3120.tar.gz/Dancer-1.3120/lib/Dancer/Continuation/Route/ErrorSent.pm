package Dancer::Continuation::Route::ErrorSent;

use strict;
use warnings;
use Carp;

use base qw(Dancer::Continuation::Route);

1;

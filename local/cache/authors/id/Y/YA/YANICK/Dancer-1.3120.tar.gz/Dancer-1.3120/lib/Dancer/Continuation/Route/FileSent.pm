package Dancer::Continuation::Route::FileSent;

use strict;
use warnings;
use Carp;

use base qw(Dancer::Continuation::Route);

1;

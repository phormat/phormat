package Dancer::Continuation::Halted;

use strict;
use warnings;
use Carp;

use base qw(Dancer::Continuation);

1;
